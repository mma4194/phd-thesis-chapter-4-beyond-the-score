# TIOT v7.14.5 execution and artifact runbook

    ## Required execution order

    0. Confirm that the engine, notebook basename, report-root version, Makefile, SLURM template, and archive basename all identify v7.14.5.

    1. Run `TIOT_MODE=smoke` in a fresh report root and confirm the complete path executes.
    2. Run `TIOT_MODE=calibrate` on a contiguous real-data slice for schema, memory, and cost calibration.
    3. Run `TIOT_MODE=real` on the complete deployment with exactly five primary seeds and at least three rolling origins.
    4. Mark only claims actually reported using `reported_in_manuscript=true` in `manuscript_claim_ledger_template.csv`, assign each a reporting role, save the filled manifest, and rerun Cells 10--11.

    An external dataset is not required because no suitable equivalent deployment is available. The manuscript
    must state this constraint and keep all empirical claims deployment-scoped. External replication remains a
    future-work recommendation, not an invented or proxy experiment.

    ## Current methodology hash

    `592075a39c6a1c0cc8332db9c1b2aba6182c721c3b2cf9ff76c86f859f596195`

    ## Non-negotiable contracts

    - TRAIN selects targets, predictors, thresholds, coupling pairs, and task definitions.
    - VAL admits task-model cards. TEST is untouched until the final frozen benchmark.
    - Primary random seeds and rolling origins are different estimands and are never pooled.
    - TRTR is fold-specific and uses the same chronology and matched training-row cap as TSTR.
    - Utility is licensed by reviewer-facing capability using disjoint TRAIN calibration and qualification block pairs.
    - Temporal utility additionally requires an order-preserving source.
    - Same-period and future axes are reported separately; their paired log-ratio gap is a descriptive relative-transfer contrast and must not be interpreted as a causal drift effect.
    - Loss ratio and stable relative excess loss versus the naive baseline are both reported.
    - Missingness indicators are constructed before imputation; observed zero is not equated with unobserved zero.
    - Learned controls use a TRAIN-frozen support-aware scope; the temporal comparator uses genuine adjacent pairs, held-out TRAIN validation, residual simulation, and empirical support restoration.
    - Execution completion and scientific-fit validity are separate states.
    - Disclosure diagnostics use disjoint same-period data; no formal privacy claim is made.
    - Negative release or generator outcomes remain publishable and must not be hidden.

    ## Important environment variables

    - `TIOT_MODE`: smoke, calibrate, or real
    - `TIOT_RUN_PROFILE`: `full` or `learned_health`; use the latter before another full campaign
    - `TIOT_DATASET_PARQUET`: input parquet/pickle/CSV
    - `TIOT_REPORT_ROOT`: a fresh output root
    - `TIOT_NOTEBOOK_PATH`: the exact notebook file to content-hash
    - `TIOT_ETHICS_STATUS`, `TIOT_ETHICS_REFERENCE`: approval/exemption/determination
    - `TIOT_MANUSCRIPT_CLAIM_LEDGER`: path to the filled reported-claim manifest; publication readiness fails closed when it is absent or contains no explicitly reported claim
    - `TIOT_INCLUDE_LEGACY_LEARNED`: optionally run legacy learned diagnostics; disabled by default
    